
	<div id="dialog_preview_sliders" class="dialog_preview_sliders" title="Preview Slider" style="display:none;">
		<iframe id="frame_preview_slider" name="frame_preview_slider"></iframe>
	</div>

	<form id="form_preview" name="form_preview" action="" target="frame_preview_slider" method="post">
		<input type="hidden" name="client_action" value="preview_slider">
		<input type="hidden" id="preview_sliderid" name="sliderid" value="">
	</form>
	
	