DROP TABLE `#__uniterevolution_sliders`;
DROP TABLE `#__uniterevolution_slides`;