UPDATE `#__modules` SET `ordering` = 2 WHERE `position` = 'status' AND `module` = 'mod_status' AND `client_id`=1;

